package com.cg.banking.services;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.beans.Address;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	BankingDAOServicesImpl  bankingDAOServices=new BankingDAOServicesImpl();
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String customerEmailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
		return bankingDAOServices.insertCustomer(new Customer(firstName,lastName,customerEmailId,panCard,new Address(localAddressCity,localAddressState,localAddressPinCode),new Address(homeAddressCity,homeAddressState,homeAddressPinCode)));
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
	CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		return bankingDAOServices.insertAccount(customerId, new Account(accountType,initBalance));
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		bankingDAOServices.getAccount(customerId, accountNo).setAccountBalance(bankingDAOServices.getAccount(customerId, accountNo).getAccountBalance()+amount);
		bankingDAOServices.insertTransaction(customerId, accountNo, new Transaction(amount,"Deposit"));
		return bankingDAOServices.getAccount(customerId, accountNo).getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		if(bankingDAOServices.getAccount(customerId, accountNo).getPinNumber()==pinNumber)
			if(bankingDAOServices.getAccount(customerId, accountNo).getAccountBalance()-amount>0){
				bankingDAOServices.getAccount(customerId, accountNo).setPinCounter(0);
				bankingDAOServices.getAccount(customerId, accountNo).setAccountBalance(bankingDAOServices.getAccount(customerId, accountNo).getAccountBalance()-amount);
				bankingDAOServices.insertTransaction(customerId, accountNo, new Transaction(amount,"Withdrawl"));
				return bankingDAOServices.getAccount(customerId, accountNo).getAccountBalance();
		}
			else {
				bankingDAOServices.getAccount(customerId, accountNo).setPinCounter(bankingDAOServices.getAccount(customerId, accountNo).getPinCounter()+1);
				bankingDAOServices.getAccount(customerId, accountNo).setStatus("Blocked");
			}
		return -1;
	}
	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		float a=withdrawAmount(customerIdFrom, accountNoFrom,transferAmount, pinNumber);
		if (a!=-1){
		depositAmount(customerIdTo, accountNoTo,transferAmount);
		return true;
		}
		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		return	bankingDAOServices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
	return bankingDAOServices.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		return  bankingDAOServices.generatePin(customerId, bankingDAOServices.getAccount(customerId, accountNo));
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		if(oldPinNumber==bankingDAOServices.getAccount(customerId, accountNo).getPinNumber()) {
			bankingDAOServices.getAccount(customerId, accountNo).setPinNumber(newPinNumber);
			return true;
		}
		return false;
	}

	@Override
	public Customer[] getAllCustomerDetails() throws BankingServicesDownException {
		return bankingDAOServices.getCustomers();
	}

	@Override
	public Account[] getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		return bankingDAOServices.getAccounts(customerId);
	}

	@Override
	public Transaction[] getAccountAllTransaction(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		return bankingDAOServices.getTransactions(customerId, accountNo);
	}

	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
	CustomerNotFoundException, AccountNotFoundException, AccountBlockedException {
		return bankingDAOServices.getAccount(customerId, accountNo).getStatus();
	}

	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		return bankingDAOServices.deleteAccount(customerId, accountNo);
	}

}
