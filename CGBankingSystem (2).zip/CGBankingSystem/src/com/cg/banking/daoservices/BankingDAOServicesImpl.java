package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import java.util.Random;

public class BankingDAOServicesImpl implements BankingDAOServices {
	private Customer[] customerList=new Customer[10];
	Random rand= new Random();
	private int CUSTOMER_IDX_COUNTER=0;
	private int CUSTOMER_ID_COUNTER=1000;
	private long ACCOUNT_NUM_GENERATOR=10000000;
	private int TRANSACTION_NUM_GENERATOR=1000;
	@Override
	public int insertCustomer(Customer customer) {		
		if (CUSTOMER_IDX_COUNTER>=0.7*customerList.length){
			Customer[] temp=new Customer[customerList.length+10];
			System.arraycopy(customerList, 0, temp, 0, CUSTOMER_IDX_COUNTER);
			customerList=temp;
		}
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		return customer.getCustomerId();
	}
	@Override
	public long insertAccount(int customerId, Account account) {
		if(getCustomer(customerId).getAccount_idx_counter()>=0.7*getAccounts(customerId).length){
		Account[] temparr = new Account[getAccounts(customerId).length];
		System.arraycopy(getAccounts(customerId), 0, temparr, 0,getCustomer(customerId).getAccount_idx_counter());
		getCustomer(customerId).setAccounts(temparr);
		}
		account.setAccountNo(ACCOUNT_NUM_GENERATOR);
		getCustomer(customerId).getAccounts()[getCustomer(customerId).getAccount_idx_counter()]=account;
		getCustomer(customerId).getAccounts()[getCustomer(customerId).getAccount_idx_counter()].setStatus("Active");
		getCustomer(customerId).setAccount_idx_counter(getCustomer(customerId).getAccount_idx_counter()+1);
		return account.getAccountNo();
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		for (int j = 0; j < getCustomer(customerId).getAccounts().length; j++) 
			if(getCustomer(customerId).getAccounts()[j].getAccountNo()==account.getAccountNo()){
				getCustomer(customerId).getAccounts()[j]=account;
				return true;
			}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		long accountNo=account.getAccountNo();
		getAccount(customerId, accountNo).setPinNumber(rand.nextInt(9999) + 1000);
		return getAccount(customerId, accountNo).getPinNumber();
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
	if(getAccount(customerId, accountNo).getTransaction_idx_counter()>=0.7*getAccount(customerId, accountNo).getTransactions().length){
		Transaction[] tempt=new Transaction[getAccount(customerId, accountNo).getTransactions().length];
		System.arraycopy(getAccount(customerId, accountNo).getTransactions().length, 0, tempt, 0, getAccount(customerId, accountNo).getTransaction_idx_counter());
		getAccount(customerId, accountNo).setTransactions(tempt);
	}
		transaction.setTransactionId(TRANSACTION_NUM_GENERATOR);
		getAccount(customerId, accountNo).getTransactions()[getAccount(customerId, accountNo).getTransaction_idx_counter()]=transaction;
		getAccount(customerId, accountNo).setTransaction_idx_counter(getAccount(customerId, accountNo).getTransaction_idx_counter()+1);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId){
				customerList[i]=null;
				for(int j=i;j<customerList.length-1;j++)
					if(customerList[j+1]!=null&&j+1<customerList.length)
						customerList[j]=customerList[j+1];	
				CUSTOMER_IDX_COUNTER--;
				return true;
			}
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		for (int j = 0; j < getCustomer(customerId).getAccounts().length; j++) 
			if(getCustomer(customerId).getAccounts()[j].getAccountNo()==accountNo){
				getCustomer(customerId).getAccounts()[j]=null;
				for(j=0;j<getCustomer(customerId).getAccounts().length-1;j++)
					if(getCustomer(customerId).getAccounts()[j+1]!=null){
						getCustomer(customerId).getAccounts()[j]=getCustomer(customerId).getAccounts()[j+1];
					}
				getAccount(customerId, accountNo).setTransaction_idx_counter(getAccount(customerId, accountNo).getTransaction_idx_counter()-1);
				return true;
			}
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId)
				return customerList[i];
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(int i=0;i<=getCustomer(customerId).getAccounts().length;i++)
		if(getCustomer(customerId).getAccounts()[i].getAccountNo()==accountNo)
			return getCustomer(customerId).getAccounts()[i];
		return null;
	}

	@Override
	public Customer[] getCustomers() {
		return customerList;
	}

	@Override
	public Account[] getAccounts(int customerId) {
		return getCustomer(customerId).getAccounts();
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		return getAccount(customerId, accountNo).getTransactions();
	}

}
