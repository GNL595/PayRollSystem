package com.cg.banking.main;

import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		try {
		BankingServicesImpl bankServices=new BankingServicesImpl();
		int cust=bankServices.acceptCustomerDetails("ravi", "teja", "email", "g55g6", "hyd", "Tg", 500072, "hyd", "Tg", 500072);
		System.out.println(cust);
		long acc=bankServices.openAccount(cust, "savings", 10000);
		System.out.println(acc);
		int pin=bankServices.generateNewPin(cust, acc);
		float bal=bankServices.depositAmount(cust, acc, 10000);
		float wit=bankServices.withdrawAmount(cust, acc, 25000,pin);
		System.out.println(pin+" "+bal+" "+wit);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
