package com.cg.payroll.main;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args){
		PayrollServicesImpl payrollServices = new PayrollServicesImpl();
int associateId1=payrollServices.acceptAssociate(150000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com", 50000, 1000,1000,13567899, "HDFC", "HD00978");
//int associateId2=payrollServices.acceptAssociate(20000, "Ravi", "teja", "java", "developer", "c345cc", "ravi@gmail.com", 30000, 2000, 200,13567899, "HDFC", "HD00978");
//int a=payrollServices.calculateNetSalary(associateId);
System.out.println(payrollServices.calculateNetSalary(associateId1)+ " "+payrollServices.getAssociateDetails(associateId1).getSalary().getGratuity()+" "+payrollServices.getAssociateDetails(associateId1).getSalary().getMonthlyTax());
	}
}