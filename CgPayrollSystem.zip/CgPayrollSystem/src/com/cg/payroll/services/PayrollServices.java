package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public interface PayrollServices {

	int acceptAssociate(int yearlyInvestmentUnder80C, String firstName, String lastName, String department,
			String designation, String pancard, String emailId, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode);

	double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException;
	
	boolean doDeleteAssociate(int associateId);

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException;

	Associate[] getAllAssociateDetails();

}